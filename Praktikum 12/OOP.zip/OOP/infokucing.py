from kucing import *

biru = kucing ("biru", "Orange", 4 )

biru.data_kucing ()