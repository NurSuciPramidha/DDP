from gempa import *
banten = gempa('Banten', 1.2)
banten.data_gempa()

palu = gempa('Palu', 6.1)
palu.data_gempa()

cianjur = gempa('Cianjur', 6.1)
cianjur.data_gempa()

jayapura = gempa('Jayapura', 3.3)
jayapura.data_gempa()

garut = gempa('Garut', 4.0)
garut.data_gempa()